// vim: fileencoding=cp1252

int main() {
    // Unicode characters not supported
    // chars that are different in common single-byte encodings:
    // �uvre, �typographic quotes�, �, �, �, �
    return 0;
}
