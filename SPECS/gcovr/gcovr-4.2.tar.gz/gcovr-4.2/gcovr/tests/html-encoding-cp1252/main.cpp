// vim: fileencoding=utf8

int main() {
    // non-BMP Unicode codepoint: ☃ (snowman)
    // chars that are different in common single-byte encodings:
    // œuvre, “typographic quotes”, ¦, ¼, €, ¤
    return 0;
}
