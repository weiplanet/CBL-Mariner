bool no(bool x) {
   if (!x) {
      return true;
   }
   return false;
}
