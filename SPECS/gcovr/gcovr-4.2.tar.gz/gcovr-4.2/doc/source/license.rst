License
=======

.. include:: ../../README.rst
   :start-after: .. begin license
   :end-before: .. end license
