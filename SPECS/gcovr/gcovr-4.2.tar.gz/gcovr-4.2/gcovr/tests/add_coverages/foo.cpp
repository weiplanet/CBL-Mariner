int foo()
{
int x=2;
int y=2;
return x+y;
}
