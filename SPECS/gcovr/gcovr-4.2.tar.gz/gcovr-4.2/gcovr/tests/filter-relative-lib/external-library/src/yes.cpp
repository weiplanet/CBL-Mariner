int yes(int x) {
   return x % 2;
}
