int foo5(int param)
{
  if (param) {
     return 1;
  } else {
     return 0;
  }
}
